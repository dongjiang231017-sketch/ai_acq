# AI ACQ realtime voice source handoff

This package contains only the local source files for the realtime voice foundation draft.
It is not a full repository, not an installer, and not a production deployment package.

## Files

- `ai_acq/backend/app/services/realtime_flight_recorder.py`
  Per-call flight recorder for trace JSONL and optional WAV evidence.
- `ai_acq/backend/app/services/realtime_turn_manager.py`
  Central turn-taking manager for VAD-like speech state, partial fast commit, and barge-in decisions.
- `ai_acq/backend/app/tools/realtime_flight_replay_eval.py`
  Local evaluator for flight-recorder traces.
- `ai_acq/backend/app/tools/realtime_audio_bridge.py`
  Bridge integration for flight events, turn manager, Omni default path, and Pipeline fallback.
- `ai_acq/backend/app/core/config.py`
  Config flags for recorder, audio capture, turn manager, and default realtime route.
- `ai_acq/backend/app/services/realtime_outbound.py`
  Default realtime route normalization.
- `ai_acq/backend/.env.example`
  Example environment variables.
- `ai_acq/docs/UC100_OUTBOUND_SETUP.md`
  Setup notes and local replay-eval command.

## Local checks previously run

From the original full repository:

```bash
cd backend
source .venv/bin/activate
python -m compileall app
python -m app.tools.realtime_call_replay_eval
python -m app.tools.realtime_sales_eval
python -m app.tools.realtime_flight_replay_eval --root /tmp/ai-acq-realtime-flight-nonexistent
```

No git commit, push, server deployment, client update, package build, or live phone call was performed for this draft.
